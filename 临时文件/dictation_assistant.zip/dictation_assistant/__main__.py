import tkinter as tk
import sys
import os

# 确保可以正确导入模块
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

try:
    # 尝试绝对导入
    from dictation_assistant.app import DictationApp
except ImportError:
    # 尝试相对导入
    try:
        from .app import DictationApp
    except ImportError:
        # 如果都失败，输出错误信息
        print("错误：无法导入DictationApp类")
        sys.exit(1)


def main():
    """主函数"""
    root = tk.Tk()
    app = DictationApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()