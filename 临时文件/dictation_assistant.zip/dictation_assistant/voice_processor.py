import os
import time
import random
from gtts import gTTS
import playsound
import speech_recognition as sr
import tkinter as tk

# 音频缓存目录
AUDIO_CACHE_DIR = "audio_cache"

# 确保缓存目录存在
if not os.path.exists(AUDIO_CACHE_DIR):
    os.makedirs(AUDIO_CACHE_DIR)


def speak(text, max_retries=3):
    """语音合成并播放"""
    # 生成缓存文件名
    cache_filename = os.path.join(AUDIO_CACHE_DIR, f"{text.replace(' ', '_')}.mp3")
    
    # 尝试最多 max_retries 次
    for retry in range(max_retries):
        try:
            # 检查缓存是否存在
            if not os.path.exists(cache_filename):
                # 不存在则创建
                tts = gTTS(text=text, lang='en')
                tts.save(cache_filename)
            
            # 播放音频
            playsound.playsound(cache_filename)
            return True
            
        except Exception as e:
            print(f"语音播放失败 (尝试 {retry+1}/{max_retries}): {e}")
            # 每次失败后稍微延迟一下
            time.sleep(1)
            
            # 如果是最后一次尝试仍失败，尝试删除缓存文件
            if retry == max_retries - 1 and os.path.exists(cache_filename):
                try:
                    os.remove(cache_filename)
                except:
                    pass
    
    return False


def recognize_speech():
    """语音识别"""
    recognizer = sr.Recognizer()
    
    # 创建一个临时的Tk窗口用于显示波形动画
    window = tk.Toplevel()
    window.title("正在录音...")
    window.geometry("300x100")
    window.configure(bg="#f0f0f0")
    
    # 创建波形动画画布
    canvas = tk.Canvas(window, width=280, height=60, bg="#f0f0f0", highlightthickness=0)
    canvas.pack(pady=20)
    
    # 创建动画线程控制变量
    is_recording = True
    
    # 开始录音
    with sr.Microphone() as source:
        print("正在录音，请说话...")
        recognizer.adjust_for_ambient_noise(source)
        
        # 在主线程中运行动画
        def animate_waveform():
            if not is_recording:
                window.destroy()
                return
            
            canvas.delete("all")
            center_y = 30
            width = 280
            bar_width = 4
            spacing = 2
            
            # 绘制随机波形
            for i in range(0, width, bar_width + spacing):
                height = random.randint(5, 50)
                x1 = i
                y1 = center_y - height // 2
                x2 = i + bar_width
                y2 = center_y + height // 2
                
                # 随机颜色模拟音频波形
                color = f"#{random.randint(74, 122):02x}{random.randint(122, 188):02x}{random.randint(188, 220):02x}"
                canvas.create_rectangle(x1, y1, x2, y2, fill=color)
            
            # 继续动画
            window.after(50, animate_waveform)
        
        # 开始动画
        animate_waveform()
        
        try:
            # 最多识别5秒
            audio = recognizer.listen(source, timeout=5)
            is_recording = False
            
            # 尝试识别
            text = recognizer.recognize_google(audio, language='en-US')
            print(f"识别结果: {text}")
            return text.lower()
            
        except sr.UnknownValueError:
            print("无法识别语音")
            is_recording = False
            return ""
        except sr.RequestError as e:
            print(f"语音识别服务错误: {e}")
            is_recording = False
            return ""
        except sr.WaitTimeoutError:
            print("录音超时")
            is_recording = False
            return ""
        except Exception as e:
            print(f"语音识别出错: {e}")
            is_recording = False
            return ""