import tkinter as tk
from tkinter import messagebox, ttk
import random
import threading
import time
import re
from .data_manager import (
    word_dict, save_wrong, load_stats, save_stats,
    log_start_session, log_end_session, load_word_weights, WRONG_FILE
)
from .voice_processor import speak, recognize_speech


class DictationApp:
    def __init__(self, root):
        # 设置主题颜色 - 更现代的配色方案
        self.theme = {
            "primary": "#4285F4",  # Google蓝
            "secondary": "#34A853",  # Google绿
            "text": "#202124",  # 深色文本
            "success": "#34A853",  # 成功绿色
            "error": "#EA4335",  # 错误红色
            "warning": "#FBBC05",  # 警告黄色
            "background": "#F8F9FA",  # 浅灰色背景
            "card_bg": "#FFFFFF",  # 卡片白色背景
            "border": "#E8EAED",  # 边框色
            "hover": "#F1F3F4"  # 悬停色
        }
        
        self.root = root
        self.root.title("英语听写助手")
        self.root.geometry("800x600")
        self.root.minsize(600, 500)
        self.root.configure(bg=self.theme["background"])
        
        # 绑定回车键提交答案
        self.root.bind('<Return>', lambda event: self.check_answer())
        
        # 初始化变量
        self.word = ""
        self.meaning = ""
        self.mode = None
        self.stats = load_stats()
        self.hint_used = False
        self.history = []
        self.session_index = None
        self.current_page = None
        self.page_stack = []
        
        # 设置ttk主题样式
        self._setup_ttk_theme()
        
        # 创建页面容器
        self.container = ttk.Frame(self.root)
        self.container.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        # 创建导航栏
        self._create_navigation_bar()
        
        # 创建所有页面
        self._create_pages()
        
        # 添加学习记录
        self.session_index = log_start_session()
        
        # 显示欢迎页
        self.show_page("welcome")
        
        # 窗口关闭事件
        self.root.protocol("WM_DELETE_WINDOW", self.exit_app)
        
    def _create_stats_page(self):
        """创建统计页面"""
        page = self.pages["stats"]
        
        title = ttk.Label(
            page,
            text="学习统计",
            style="Subheading.TLabel"
        )
        title.pack(pady=20)
        
        # 统计卡片
        stats_card = ttk.Frame(page, style="Card.TFrame")
        stats_card.pack(pady=20, fill=tk.BOTH, expand=True, padx=50)
        
        # 使用self.stats_label而不是self.stats_text以保持一致性
        self.stats_label = ttk.Label(
            stats_card,
            text=self.get_stats_text(),
            font=("微软雅黑", 14),
            justify=tk.LEFT,
            foreground=self.theme["text"]
        )
        self.stats_label.pack(pady=30, padx=30, anchor="w")
        
        # 返回首页按钮
        back_button = ttk.Button(
            page,
            text="返回首页",
            style="Primary.TButton",
            padding=15,
            command=lambda: self.show_page("welcome")
        )
        back_button.pack(pady=20)
    
    def set_mode(self, mode):
        """设置学习模式"""
        self.mode = mode
    
    def show_page(self, page_name):
        """显示指定页面，实现页面切换效果"""
        if page_name in self.pages:
            # 隐藏当前页面
            if self.current_page:
                self.pages[self.current_page].pack_forget()
                self.page_stack.append(self.current_page)
            else:
                self.page_stack = []
            
            # 更新当前页面
            self.current_page = page_name
            
            # 显示新页面
            self.pages[page_name].pack(fill=tk.BOTH, expand=True)
            
            # 更新导航栏
            self.btn_back.config(state=tk.NORMAL if page_name != "welcome" else tk.DISABLED)
            
            # 更新导航标题
            titles = {
                "welcome": "英语听写助手",
                "learn": f"学习模式 - {self._get_mode_name()}",
                "review": "错题复习",
                "stats": "学习统计"
            }
            self.nav_title.config(text=titles.get(page_name, "英语听写助手"))
            
            # 页面特定初始化
            if page_name == "learn":
                self._init_learn_page()
            elif page_name == "stats":
                # 修复stats_text引用错误
                if hasattr(self, 'stats_label'):
                    self.stats_label.config(text=self.get_stats_text(), foreground=self.theme["text"])
    
    def go_back(self):
        """返回上一页"""
        if self.page_stack:
            previous_page = self.page_stack.pop()
            self.show_page(previous_page)
        else:
            self.show_page("welcome")
    
    def _get_mode_name(self):
        """获取当前模式的中文名称"""
        mode_names = {
            "E2C": "英译汉",
            "C2E": "汉译英",
            "LISTEN": "听写拼写",
            "REVIEW": "错题复习"
        }
        return mode_names.get(self.mode, "未知模式")
    
    def _init_learn_page(self):
        """初始化学习页面"""
        self.hint_used = False
        self.btn_hint.config(state=tk.NORMAL)
        self.btn_next.config(state=tk.DISABLED)
        self.entry.delete(0, tk.END)
        self.entry.focus_set()
        
        # 隐藏听写模式的播放按钮（在各模式方法中根据需要显示）
        self.play_button.pack_forget()
        
        # 确保question_label有正确的前景色
        self.question_label.config(foreground=self.theme["text"])
        
        # 根据模式初始化
        if self.mode == "E2C":
            self.english_to_chinese()
        elif self.mode == "C2E":
            self.chinese_to_english()
        elif self.mode == "LISTEN":
            self.listen_and_spell()
    
    def start_review(self):
        """开始错题复习"""
        import json
        import os
        
        if os.path.exists(WRONG_FILE):
            try:
                with open(WRONG_FILE, "r", encoding="utf-8") as f:
                    wrongs = json.load(f)
                
                if not wrongs:
                    messagebox.showinfo("提示", "没有错题记录！")
                    return
                
                # 从错题本中随机选择一个单词
                wrong_item = random.choice(wrongs)
                word = list(wrong_item.keys())[0]
                meaning = wrong_item[word]
                self.review_word = {"word": word, "translation": meaning}
                
                # 设置复习模式和问题
                self.review_mode = random.choice(["E2C", "C2E"])
                
                # 清空复习卡片
                for widget in self.review_card.winfo_children():
                    widget.destroy()
                
                if self.review_mode == "E2C":
                    self.review_label = ttk.Label(
                        self.review_card,
                        text=f"英译汉: {word}",
                        font=("微软雅黑", 16),
                        foreground=self.theme["text"]
                    )
                else:
                    self.review_label = ttk.Label(
                        self.review_card,
                        text=f"汉译英: {meaning}",
                        font=("微软雅黑", 16),
                        foreground=self.theme["text"]
                    )
                
                self.review_label.pack(pady=20)
                
                # 创建输入区域
                input_frame = ttk.Frame(self.review_card)
                input_frame.pack(pady=15, fill=tk.X)
                
                self.review_entry = ttk.Entry(
                    input_frame,
                    style="Custom.TEntry"
                )
                self.review_entry.pack(fill=tk.X, expand=True, padx=5)
                
                # 操作按钮
                action_frame = ttk.Frame(self.review_card)
                action_frame.pack(pady=15)
                
                self.review_submit = ttk.Button(
                    action_frame,
                    text="提交答案",
                    style="Primary.TButton",
                    command=self.check_review_answer
                )
                self.review_submit.pack(side=tk.LEFT, padx=10)
                
                self.review_next = ttk.Button(
                    action_frame,
                    text="下一题",
                    style="Secondary.TButton",
                    command=self.start_review,
                    state=tk.DISABLED
                )
                self.review_next.pack(side=tk.LEFT, padx=10)
                
            except Exception as e:
                print(f"复习错题出错: {e}")
                messagebox.showerror("错误", "加载错题记录失败")
        else:
            messagebox.showinfo("提示", "没有错题记录！")
    
    def check_review_answer(self):
        """检查复习答案"""
        user_answer = self.review_entry.get().strip()
        if not user_answer:
            messagebox.showwarning("提示", "请输入答案")
            return

        if self.review_mode == "E2C":
            correct_answer = self.review_word["translation"]
            is_correct = user_answer.lower() in correct_answer.lower() or correct_answer.lower() in user_answer.lower()
        else:
            correct_answer = self.review_word["word"]
            is_correct = user_answer.lower() == correct_answer.lower()

        if is_correct:
            # 显示成功动画效果
            original_color = self.theme["text"]
            success_color = self.theme["success"]
            
            def blink():
                for _ in range(3):
                    self.review_label.config(foreground=success_color)
                    self.root.update()
                    time.sleep(0.1)
                    self.review_label.config(foreground=original_color)
                    self.root.update()
                    time.sleep(0.1)
            
            threading.Thread(target=blink, daemon=True).start()
            
            messagebox.showinfo("正确", "恭喜，回答正确！")
            # 从错题本中移除已掌握的单词
            import json
            import os
            with open(WRONG_FILE, "r", encoding="utf-8") as f:
                wrongs = json.load(f)
            
            for i, item in enumerate(wrongs):
                if list(item.keys())[0] == self.review_word["word"]:
                    wrongs.pop(i)
                    break
            
            # 更新错题本
            with open(WRONG_FILE, "w", encoding="utf-8") as f:
                json.dump(wrongs, f, ensure_ascii=False, indent=2)
        else:
            messagebox.showerror("错误", f"回答错误！正确答案是：{correct_answer}")

        # 更新统计信息
        self.update_stats(is_correct)
        
        self.review_entry.delete(0, tk.END)
        self.review_submit.config(state=tk.DISABLED)
        self.review_next.config(state=tk.NORMAL)
    
    def _setup_ttk_theme(self):
        """设置ttk主题样式"""
        style = ttk.Style()
        
        # 配置默认标签样式，确保所有标签都有明确的文本颜色
        style.configure(
            "TLabel",
            foreground=self.theme["text"],  # 确保默认文本颜色
            background=self.theme["background"]
        )
        
        # 配置标题样式
        style.configure(
            "Heading.TLabel",
            font=('微软雅黑', 28, 'bold'),
            foreground=self.theme["primary"],
            background=self.theme["background"]
        )
        
        style.configure(
            "Subheading.TLabel",
            font=('微软雅黑', 20),
            foreground=self.theme["text"],
            background=self.theme["background"]
        )
        
        # 配置卡片样式
        style.configure(
            "Card.TFrame",
            background=self.theme["card_bg"],
            relief="flat",
            padding=20
        )
        
        # 配置按钮样式
        style.configure(
            "Primary.TButton",
            font=('微软雅黑', 12),
            padding=15,
            background=self.theme["primary"],
            foreground="white"
        )
        
        style.configure(
            "Secondary.TButton",
            font=('微软雅黑', 12),
            padding=15,
            background=self.theme["secondary"],
            foreground="white"
        )
        
        style.configure(
            "Custom.TButton",
            font=('微软雅黑', 12),
            padding=15,
            foreground=self.theme["text"]
        )
        
        # 配置输入框样式
        style.configure(
            "Custom.TEntry",
            font=('微软雅黑', 14),
            padding=10,
            fieldbackground="white",
            foreground=self.theme["text"]
        )
        
        # 配置单选按钮样式
        style.configure(
            "TRadiobutton",
            foreground=self.theme["text"],
            background=self.theme["background"]
        )
    
    def _create_navigation_bar(self):
        """创建顶部导航栏"""
        self.nav_bar = ttk.Frame(self.root, height=60)
        self.nav_bar.pack(fill=tk.X, side=tk.TOP, padx=20, pady=(0, 10))
        
        # 返回按钮
        self.btn_back = ttk.Button(
            self.nav_bar,
            text="← 返回",
            style="Custom.TButton",
            command=self.go_back,
            state=tk.DISABLED
        )
        self.btn_back.pack(side=tk.LEFT, padx=5)
        
        # 导航标题
        self.nav_title = ttk.Label(
            self.nav_bar,
            text="英语听写助手",
            font=('微软雅黑', 16, 'bold'),
            foreground=self.theme["primary"]
        )
        self.nav_title.pack(side=tk.LEFT, padx=20)
        
        # 右侧导航按钮
        self.btn_nav_review = ttk.Button(
            self.nav_bar,
            text="复习错题",
            style="Custom.TButton",
            command=lambda: self.show_page("review")
        )
        self.btn_nav_review.pack(side=tk.RIGHT, padx=5)
        
        self.btn_nav_stats = ttk.Button(
            self.nav_bar,
            text="学习统计",
            style="Custom.TButton",
            command=lambda: self.show_page("stats")
        )
        self.btn_nav_stats.pack(side=tk.RIGHT, padx=5)
    
    def _create_pages(self):
        """创建所有页面框架"""
        self.pages = {}
        
        # 创建欢迎页
        self.pages["welcome"] = ttk.Frame(self.container)
        self._create_welcome_page()
        
        # 创建学习页面
        self.pages["learn"] = ttk.Frame(self.container)
        self._create_learn_page()
        
        # 创建复习页面
        self.pages["review"] = ttk.Frame(self.container)
        self._create_review_page()
        
        # 创建统计页面
        # 注意：_create_stats_page方法已经在前面定义
    
    def _create_welcome_page(self):
        """创建欢迎页面"""
        page = self.pages["welcome"]
        
        # 标题
        title_label = ttk.Label(
            page,
            text="英语听写助手",
            style="Heading.TLabel"
        )
        title_label.pack(pady=40)
        
        # 欢迎语
        welcome_text = ttk.Label(
            page,
            text="选择您的学习模式开始学习",
            style="Subheading.TLabel"
        )
        welcome_text.pack(pady=20)
        
        # 学习模式卡片
        card_frame = ttk.Frame(page, style="Card.TFrame")
        card_frame.pack(pady=30, padx=100, fill=tk.BOTH, expand=True)
        
        # 难度选择
        difficulty_frame = ttk.Frame(card_frame)
        difficulty_frame.pack(pady=20)
        
        difficulty_label = ttk.Label(
            difficulty_frame,
            text="选择难度:  ",
            font=("微软雅黑", 12),
            foreground=self.theme["text"]
        )
        difficulty_label.pack(side=tk.LEFT, padx=5)
        
        self.difficulty_var = tk.StringVar(value="normal")
        difficulties = [("简单", "easy"), ("普通", "normal"), ("困难", "hard")]
        
        for text, value in difficulties:
            ttk.Radiobutton(
                difficulty_frame,
                text=text,
                variable=self.difficulty_var,
                value=value,
                style="TRadiobutton"
            ).pack(side=tk.LEFT, padx=10)
        
        # 模式按钮容器
        modes_container = ttk.Frame(card_frame)
        modes_container.pack(pady=30, fill=tk.X)
        
        # 模式选择按钮
        self.btn_e2c = ttk.Button(
            modes_container,
            text="📝 英译汉",
            style="Primary.TButton",
            padding=20,
            command=lambda: [self.set_mode("E2C"), self.show_page("learn")]
        )
        self.btn_e2c.pack(fill=tk.X, padx=30, pady=10)
        
        self.btn_c2e = ttk.Button(
            modes_container,
            text="📖 汉译英",
            style="Primary.TButton",
            padding=20,
            command=lambda: [self.set_mode("C2E"), self.show_page("learn")]
        )
        self.btn_c2e.pack(fill=tk.X, padx=30, pady=10)
        
        self.btn_listen = ttk.Button(
            modes_container,
            text="🔊 听写拼写",
            style="Primary.TButton",
            padding=20,
            command=lambda: [self.set_mode("LISTEN"), self.show_page("learn")]
        )
        self.btn_listen.pack(fill=tk.X, padx=30, pady=10)
    
    def _create_learn_page(self):
        """创建学习页面"""
        page = self.pages["learn"]
        
        # 问题卡片
        question_card = ttk.Frame(page, style="Card.TFrame")
        question_card.pack(pady=20, fill=tk.X)
        
        # 问题显示标签
        self.question_label = ttk.Label(
            question_card,
            text="加载中...",
            font=("微软雅黑", 18),
            wraplength=700,
            foreground=self.theme["text"]
        )
        self.question_label.pack(pady=30)
        
        # 播放按钮 (听写模式使用)
        self.play_button = ttk.Button(
            question_card,
            text="🔊 播放单词",
            style="Secondary.TButton",
            command=self.play_word_audio
        )
        
        # 输入区域
        input_frame = ttk.Frame(page)
        input_frame.pack(pady=20, fill=tk.X, padx=100)
        
        self.entry = ttk.Entry(
            input_frame,
            style="Custom.TEntry"
        )
        self.entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=5)
        
        # 操作按钮
        action_frame = ttk.Frame(page)
        action_frame.pack(pady=20)
        
        self.btn_submit = ttk.Button(
            action_frame,
            text="提交答案",
            style="Primary.TButton",
            command=self.check_answer
        )
        self.btn_submit.pack(side=tk.LEFT, padx=10)
        
        self.btn_voice = ttk.Button(
            action_frame,
            text="🎤 语音输入",
            style="Secondary.TButton",
            command=self.voice_answer
        )
        self.btn_voice.pack(side=tk.LEFT, padx=10)
        
        self.btn_hint = ttk.Button(
            action_frame,
            text="💡 提示",
            style="Custom.TButton",
            command=self.show_hint
        )
        self.btn_hint.pack(side=tk.LEFT, padx=10)
        
        # 下一题按钮
        self.btn_next = ttk.Button(
            page,
            text="下一题",
            style="Primary.TButton",
            command=self.next_question
        )
        self.btn_next.pack(pady=20)
    
    def _create_review_page(self):
        """创建复习页面"""
        page = self.pages["review"]
        
        title = ttk.Label(
            page,
            text="错题复习",
            style="Subheading.TLabel"
        )
        title.pack(pady=20)
        
        # 复习卡片
        self.review_card = ttk.Frame(page, style="Card.TFrame")
        self.review_card.pack(pady=20, fill=tk.BOTH, expand=True, padx=100)
        
        self.review_label = ttk.Label(
            self.review_card,
            text="点击下方按钮开始复习错题",
            font=("微软雅黑", 16),
            foreground=self.theme["text"]
        )
        self.review_label.pack(pady=50)
        
        start_button = ttk.Button(
            page,
            text="开始复习",
            style="Primary.TButton",
            padding=20,
            command=self.start_review
        )
        start_button.pack(pady=30)
    
    def add_hover_effect(self, button, hover_color=None):
        """为按钮添加悬停效果"""
        original_color = button.cget("bg")
        if hover_color is None:
            # 自动计算悬停颜色（稍深一些）
            if original_color.startswith("#"):
                r, g, b = int(original_color[1:3], 16), int(original_color[3:5], 16), int(original_color[5:7], 16)
                r, g, b = max(0, r-20), max(0, g-20), max(0, b-20)
                hover_color = f"#{r:02x}{g:02x}{b:02x}"
            else:
                hover_color = "#3a6a9c"  # 默认悬停颜色
        
        def on_enter(event):
            button.config(bg=hover_color)
            
        def on_leave(event):
            button.config(bg=original_color)
        
        button.bind("<Enter>", on_enter)
        button.bind("<Leave>", on_leave)
    
    def get_stats_text(self):
        """获取统计信息文本"""
        accuracy = 0
        if self.stats["total_questions"] > 0:
            accuracy = round(self.stats["correct_answers"] / self.stats["total_questions"] * 100, 1)
        
        return f"总题数: {self.stats['total_questions']} | 正确率: {accuracy}% | 连续正确: {self.stats['streak']} | 最佳连续: {self.stats['best_streak']}"
        
    def update_stats(self, is_correct):
        """更新学习统计"""
        self.stats["total_questions"] += 1
        
        if is_correct:
            self.stats["correct_answers"] += 1
            self.stats["streak"] += 1
            self.stats["best_streak"] = max(self.stats["best_streak"], self.stats["streak"])
        else:
            self.stats["wrong_answers"] += 1
            self.stats["streak"] = 0
        
        save_stats(self.stats)
        self.stats_label.config(text=self.get_stats_text())
    
    def exit_app(self):
        """安全退出应用"""
        if messagebox.askyesno("确认退出", "确定要退出英语听写助手吗？"):
            if self.session_index is not None:
                log_end_session(self.session_index)
            self.root.quit()

    def english_to_chinese(self):
        self.mode = "E2C"
        self.hint_used = False
        self.word = self.get_word_by_difficulty()
        self.meaning = word_dict[self.word]
        self.question_label.config(text=f"英文：{self.word}", foreground=self.theme["text"])
        self.btn_hint.config(state=tk.NORMAL)
        self.btn_next.config(state=tk.DISABLED)
        self.entry.focus_set()
        
    def chinese_to_english(self):
        self.mode = "C2E"
        self.hint_used = False
        self.word, self.meaning = self.get_word_pair_by_difficulty()
        self.question_label.config(text=f"中文：{self.meaning}", foreground=self.theme["text"])
        self.btn_hint.config(state=tk.NORMAL)
        self.btn_next.config(state=tk.DISABLED)
        self.entry.focus_set()
    
    def get_word_by_difficulty(self):
        """根据难度获取单词"""
        difficulty = self.difficulty_var.get()
        words = list(word_dict.keys())
        
        if difficulty == "easy":
            # 简单模式：只选择短单词（4个字母以下）
            easy_words = [w for w in words if len(w) <= 4]
            if easy_words:
                words = easy_words
        elif difficulty == "hard":
            # 困难模式：只选择长单词（6个字母以上）
            hard_words = [w for w in words if len(w) >= 6]
            if hard_words:
                words = hard_words
        
        # 根据权重选择单词
        weights = load_word_weights()
        if weights:
            # 计算权重总和
            total_weight = sum(weights.get(word, 1) for word in words)
            # 生成随机值
            r = random.uniform(0, total_weight)
            # 根据权重选择单词
            cumulative = 0
            for word in words:
                cumulative += weights.get(word, 1)
                if r <= cumulative:
                    return word
        
        return random.choice(words)
    
    def get_word_pair_by_difficulty(self):
        """根据难度获取单词对"""
        difficulty = self.difficulty_var.get()
        word_pairs = list(word_dict.items())
        
        if difficulty == "easy":
            # 简单模式：只选择短单词（4个字母以下）
            easy_pairs = [(w, m) for w, m in word_pairs if len(w) <= 4]
            if easy_pairs:
                word_pairs = easy_pairs
        elif difficulty == "hard":
            # 困难模式：只选择长单词（6个字母以上）
            hard_pairs = [(w, m) for w, m in word_pairs if len(w) >= 6]
            if hard_pairs:
                word_pairs = hard_pairs
        
        # 根据权重选择单词对
        weights = load_word_weights()
        if weights:
            # 计算权重总和
            total_weight = sum(weights.get(word, 1) for word, _ in word_pairs)
            # 生成随机值
            r = random.uniform(0, total_weight)
            # 根据权重选择单词对
            cumulative = 0
            for word, meaning in word_pairs:
                cumulative += weights.get(word, 1)
                if r <= cumulative:
                    return word, meaning
        
        return random.choice(word_pairs)
    
    def show_hint(self):
        """显示提示"""
        if not self.hint_used:
            self.hint_used = True
            if self.mode == "E2C":
                hint = f"提示：{self.meaning[0]}..."  # 显示中文意思的第一个字
            elif self.mode == "C2E":
                hint = f"提示：{self.word[0].upper()}{'_' * (len(self.word) - 1)}"  # 显示首字母和下划线
            else:  # LISTEN
                hint = f"提示：{self.word[0].upper()}{'_' * (len(self.word) - 1)}"  # 显示首字母和下划线
            
            # 使用新的question_label
            self.question_label.config(foreground=self.theme["warning"])
            messagebox.showinfo("提示", hint)

    def listen_and_spell(self):
        try:
            self.mode = "LISTEN"
            self.hint_used = False
            self.word = self.get_word_by_difficulty()
            self.meaning = word_dict[self.word]
            self.question_label.config(text="请听单词并输入拼写：", foreground=self.theme["text"])
            self.btn_hint.config(state=tk.NORMAL)
            self.btn_next.config(state=tk.DISABLED)
            
            # 确保播放按钮正确显示在问题卡片中
            if hasattr(self, 'play_button'):
                # 确保在question_label之后显示
                self.play_button.pack(pady=20)
                
                # 同时自动播放一次
                self.play_word_audio()
            
            self.entry.focus_set()
        except Exception as e:
            print(f"听写模式初始化出错: {e}")
            messagebox.showerror("错误", f"听写模式初始化失败: {str(e)}")
    
    def play_word_audio(self):
        """播放单词音频"""
        # 禁用按钮防止重复点击
        self.play_button.config(state=tk.DISABLED, text="🔊 播放中...")
        self.root.update()
        
        # 播放语音
        success = speak(self.word)
        
        # 恢复按钮状态
        self.play_button.config(state=tk.NORMAL, text="🔊 播放单词")
        return success
    
    def next_question(self):
        """下一题"""
        # 清空输入框
        self.entry.delete(0, tk.END)
        
        # 根据模式切换
        if self.mode == "E2C":
            self.english_to_chinese()
        elif self.mode == "C2E":
            self.chinese_to_english()
        elif self.mode == "LISTEN":
            # 听写模式不需要先隐藏播放按钮，因为listen_and_spell会处理
            self.listen_and_spell()
        else:
            # 其他模式隐藏播放按钮
            if hasattr(self, 'play_button'):
                self.play_button.pack_forget()
        
        self.btn_submit.config(state=tk.NORMAL)
        self.btn_next.config(state=tk.DISABLED)
    
    def review_wrong(self):
        """复习错题"""
        import json
        import os
        from .data_manager import WRONG_FILE
        
        if os.path.exists(WRONG_FILE):
            try:
                with open(WRONG_FILE, "r", encoding="utf-8") as f:
                    wrongs = json.load(f)
                
                if not wrongs:
                    messagebox.showinfo("提示", "没有错题记录！")
                    return
                
                # 随机选择一道错题
                wrong_item = random.choice(wrongs)
                word = list(wrong_item.keys())[0]
                meaning = wrong_item[word]
                
                self.word = word
                self.meaning = meaning
                self.mode = "REVIEW"
                self.hint_used = False
                
                # 随机选择复习模式
                review_type = random.choice(["E2C", "C2E", "LISTEN"])
                
                # 使用新的question_label
                if review_type == "E2C":
                    self.question_label.config(text=f"[复习] 英文：{word}", foreground=self.theme["error"])
                elif review_type == "C2E":
                    self.question_label.config(text=f"[复习] 中文：{meaning}", foreground=self.theme["error"])
                else:  # LISTEN
                    self.question_label.config(text="[复习] 请听单词并输入拼写：", foreground=self.theme["error"])
                    # 播放单词
                    speak(word)
                
                self.btn_hint.config(state=tk.NORMAL)
                self.btn_next.config(state=tk.DISABLED)
                self.entry.focus_set()
                
            except Exception as e:
                print(f"复习错题出错: {e}")
                messagebox.showerror("错误", "加载错题记录失败")
        else:
            messagebox.showinfo("提示", "没有错题记录！")

    def check_answer(self):
        """检查用户答案是否正确"""
        user_answer = self.entry.get().strip()
        if not user_answer:
            messagebox.showwarning("提示", "请输入答案")
            return

        if self.mode == "E2C":
            correct_answer = self.meaning
            is_correct = user_answer.lower() in correct_answer.lower() or correct_answer.lower() in user_answer.lower()
        elif self.mode == "C2E":
            correct_answer = self.word
            # 忽略大小写检查
            is_correct = user_answer.lower() == correct_answer.lower()
        elif self.mode == "LISTEN":
            correct_answer = self.word
            # 忽略大小写检查
            is_correct = user_answer.lower() == correct_answer.lower()
        elif self.mode == "REVIEW":
            is_correct = (user_answer.lower() == self.meaning.lower()) or (user_answer.lower() == self.word.lower())
            if user_answer.lower() == self.meaning.lower():
                correct_answer = self.meaning
            else:
                correct_answer = self.word
        else:
            is_correct = False
            correct_answer = ""

        if is_correct:
            # 显示成功动画
            self._show_success_animation()
            messagebox.showinfo("结果", f"✅ 正确！{self.get_streak_message()}")
        else:
            messagebox.showerror("结果", f"❌ 错误！正确答案：{correct_answer}")
            # 保存错题
            save_wrong(self.word, self.meaning)

        # 更新统计信息
        self.update_stats(is_correct)
        
        # 清空输入框，启用下一题按钮
        self.entry.delete(0, tk.END)
        self.btn_next.config(state=tk.NORMAL)
        self.btn_submit.config(state=tk.DISABLED)
        self.btn_next.focus_set()
    
    def _show_success_animation(self):
        """显示成功动画效果（适配新UI）"""
        # 使用标签闪烁效果替代按钮闪烁
        original_color = self.theme["text"]
        success_color = self.theme["success"]
        
        def blink():
            for _ in range(3):
                self.question_label.config(foreground=success_color)
                self.root.update()
                time.sleep(0.1)
                self.question_label.config(foreground=original_color)
                self.root.update()
                time.sleep(0.1)
        
        # 在主线程中执行动画
        threading.Thread(target=blink, daemon=True).start()
    
    def show_success_animation(self):
        """显示成功动画效果"""
        # 闪烁标签文字颜色 - 使用新的question_label
        original_color = self.question_label.cget("foreground")
        
        def flash():
            for _ in range(2):
                self.question_label.config(foreground=self.theme["success"])
                self.root.update()
                time.sleep(0.1)
                self.question_label.config(foreground=original_color)
                self.root.update()
                time.sleep(0.1)
        
        # 在非主线程中运行动画
        thread = threading.Thread(target=flash)
        thread.daemon = True
        thread.start()
    
    def get_streak_message(self):
        """获取连续正确的鼓励信息"""
        if self.stats["streak"] >= 10:
            return "太棒了！连续正确10次！"
        elif self.stats["streak"] >= 5:
            return "真不错！继续保持！"
        elif self.stats["streak"] >= 3:
            return "很好！再接再厉！"
        return ""
    
    def voice_answer(self):
        text = recognize_speech()
        if not text:
            messagebox.showerror("错误", "没听清楚，再试一次吧～")
            return
        self.entry.delete(0, tk.END)
        self.entry.insert(0, text)
        self.check_answer()