import json
import os
from datetime import datetime

# 单词字典
word_dict = {
    "freedom": "自由",
    "knowledge": "知识",
    "success": "成功",
    "challenge": "挑战",
    "opportunity": "机会",
    "determination": "决心",
    "creativity": "创造力",
    "inspiration": "灵感"
}

# 文件常量
WRONG_FILE = "wrong_words.json"
STATS_FILE = "learning_stats.json"
WEIGHT_FILE = "word_weights.json"
LOG_FILE = "learning_log.json"


def save_wrong(word, meaning):
    """保存错题记录"""
    wrongs = []
    if os.path.exists(WRONG_FILE):
        try:
            with open(WRONG_FILE, "r", encoding="utf-8") as f:
                wrongs = json.load(f)
        except:
            pass
    
    # 检查是否已存在相同的错题
    exists = False
    for item in wrongs:
        if word in item and item[word] == meaning:
            exists = True
            break
    
    if not exists:
        wrongs.append({word: meaning})
        
        try:
            with open(WRONG_FILE, "w", encoding="utf-8") as f:
                json.dump(wrongs, f, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"保存错题失败: {e}")
    
    # 更新单词权重
    update_word_weight(word)


def update_word_weight(word):
    """更新单词权重（出错越多权重越高）"""
    weights = load_word_weights()
    weights[word] = weights.get(word, 0) + 1
    
    try:
        with open(WEIGHT_FILE, "w", encoding="utf-8") as f:
            json.dump(weights, f, ensure_ascii=False, indent=2)
    except Exception as e:
        print(f"更新单词权重失败: {e}")


def load_word_weights():
    """加载单词权重"""
    if os.path.exists(WEIGHT_FILE):
        try:
            with open(WEIGHT_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except:
            pass
    return {}


def load_stats():
    """加载学习统计信息"""
    if os.path.exists(STATS_FILE):
        try:
            with open(STATS_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except:
            pass
    
    # 返回默认统计信息
    return {
        "total_questions": 0,
        "correct_answers": 0,
        "wrong_answers": 0,
        "streak": 0,
        "best_streak": 0
    }


def save_stats(stats):
    """保存学习统计信息"""
    try:
        with open(STATS_FILE, "w", encoding="utf-8") as f:
            json.dump(stats, f, ensure_ascii=False, indent=2)
    except Exception as e:
        print(f"保存统计信息失败: {e}")


def log_start_session():
    """记录学习会话开始时间"""
    logs = []
    if os.path.exists(LOG_FILE):
        try:
            with open(LOG_FILE, "r", encoding="utf-8") as f:
                logs = json.load(f)
        except:
            pass
    
    logs.append({
        "start_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "end_time": None
    })
    
    try:
        with open(LOG_FILE, "w", encoding="utf-8") as f:
            json.dump(logs, f, ensure_ascii=False, indent=2)
    except Exception as e:
        print(f"记录会话开始失败: {e}")
    
    return len(logs) - 1


def log_end_session(session_index):
    """记录学习会话结束时间"""
    if os.path.exists(LOG_FILE):
        try:
            with open(LOG_FILE, "r", encoding="utf-8") as f:
                logs = json.load(f)
            
            if 0 <= session_index < len(logs):
                logs[session_index]["end_time"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                
                with open(LOG_FILE, "w", encoding="utf-8") as f:
                    json.dump(logs, f, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"记录会话结束失败: {e}")