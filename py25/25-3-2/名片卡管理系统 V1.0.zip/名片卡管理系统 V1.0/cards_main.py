import cards_tools


def main():
    while True:
        print('*' * 40)
        print('欢迎使用【名片管理系统】V1.0')
        print('')
        print("1. 新建名片")
        print('2. 显示全部')
        print('3. 查询名片')
        print('')
        print('0. 退出系统')
        print('*' * 40)
        print('')
        User_Action = input('请选择要使用的功能：')
        # 新建名片模块
        if User_Action == '1':
            cards_tools.add_business_cards(
                name=input('请输入姓名：'),
                phone=input('请输入电话：'),
                email=input('请输入电子邮件：'),
                address=input('请输入住址：')
            )
        # 显示全部模块
        elif User_Action == '2':
            cards_tools.all_cards()
        # 查改删模块
        elif User_Action == '3':
            cards_tools.query_modify_delete_mod(
                card=input('请输入想要查询的名片：'))
        # 处理异常输入，避免程序崩溃
        elif User_Action != '1' and User_Action != '2' and User_Action != '3' and User_Action != '0':
            print('')
            print('--------请输入正确的功能！--------')
            print('')
        # 程序运行结束
        else:
            print('-----感谢您的使用！-----')
            break


if __name__ == '__main__':
    main()
